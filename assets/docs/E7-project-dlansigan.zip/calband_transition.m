function [instructions] = calband_transition(initial_formation, target_formation, max_beats)
% [instructions] = calband_template(initial_formation, target_formation, max_beats)
% DESCRIPTION

%%
%------------------------%
%--Initialize variables--%
%------------------------%

%    n_bandmembers----------total number of band members on the field
%
%    instructions-----------output structure array
%
%    initPosArr-------------cell array with the initial coordinates of each 
%                           band member
%
%    targetPosArr-----------array with the final coordinates of each band 
%                           member. Starts out as an array of coordinates 
%                           of target positions with no particular order 
%                           but gets rearranged later on to correspond with 
%                           certain marchers
%
%    closestTargetArr-------cell array with coordinates of targets that are
%                           closest to each marcher to a specified degree. 
%                           This is initially the set of closest target 
%                           positions to each marcher retrieved in Step 1,
%                           but it changes later on to solve duplication
%                           problem.
%    stepsArr---------------array with the number of steps each marcher
%                           takes to reach target position
%
%    sortedMarchers---------array with the marchers sorted according to
%                           priority rules in Step 2


%% Finds the number of bandmembers by adding up all the 1s in the target
n_bandmembers = sum(sum(target_formation));

%% Makes a structure with the appropriate fields (without any actual data)
% and copies it nb times to get a 1 x nb array of structs
instructions = struct('i_target',[],'j_target',[],'wait',[],'direction',[]);
instructions = repmat(instructions,1,n_bandmembers);

%% Make array with coordinates of each band member.
initPosArr = zeros( n_bandmembers, 2 );
for k = 1:n_bandmembers
    [ m, n ] = find( initial_formation==k );
    initPosArr( k, : ) = [ m, n ];
end

%% Make array with possible target coordinates of each band member.
[ m, n ] = find(target_formation); %2xn array, where n is the number of marchers
targetPosArr = [ m, n ];

%%
%---------------------%
%-- START ALGORITHM --%
%---------------------%

%% STEP 1: Find closest target positions to each marcher and the number of 
% steps to get to those positions.
[ closestTargetArr, stepsArr ] = findClosestTarget( n_bandmembers, initPosArr, targetPosArr );

%% STEP 2: Sort marchers so that marchers who are closest to their target 
% positions have first priority and marchers with the least possible 
% targets have second priority.
sortedMarchers = prioritySortMarchers( initPosArr, closestTargetArr, stepsArr );

%% STEP 3: Assign target positions to each marcher so that no marcher will
% go to the same spot.
targetPosArr = occupyField( target_formation, closestTargetArr, sortedMarchers, initPosArr, targetPosArr );

%% STEP 4: Check for collisions and choose the path taken for each marcher
% and the initial wait time accordingly.
[ waitArr, directionArr ] = assignMovement( initPosArr, targetPosArr, max_beats );

%% STEP 5: Put information into output struct array.
for marcherTag = 1:n_bandmembers
    instructions( marcherTag ).i_target = targetPosArr( marcherTag, 1 );
    instructions( marcherTag ).j_target = targetPosArr( marcherTag, 2 );
    instructions( marcherTag ).wait = 2 * waitArr( marcherTag );
    instructions( marcherTag ).direction = directionArr{ marcherTag };
end

end


function [ closestTargetArr, stepsArr ] = findClosestTarget( n_bandmembers, initPosArr, targetPosArr )
%Outputs cell array closestTargetArr with possible final positions of each
%marcher and array stepsArr with number of steps taken.

%% Find closest target position to each band member.
closestTargetArr = cell( n_bandmembers, 1 ); %Coordinates of closest target to each marcher.
stepsArr = zeros( n_bandmembers, 1 ); %Number of steps to those targets
%Find closest target to all band members
for marcherTag = 1:n_bandmembers
    %Call subfunction findClosestTargettoMarcher, which finds the closest
    %target to individual marchers, for each marcher.
    [ closestTargetArr{ marcherTag }, stepsArr( marcherTag ) ] =...
        findClosestTargettoMarcher( marcherTag, initPosArr, targetPosArr, 1 );
end


end

function [ closestTarget, steps ] = findClosestTargettoMarcher( marcherTag, initPosArr, targetPosArr, closeness )
%Outputs an n x 2 array closestTarget where n is the possible number of 
%final positions given a degree of closeness and a scalar number steps, 
%which is the number of steps it will take for the marcher to reach that 
%position.
steps2Take = -1; %Initialize steps2Take, which increases if no set of target solutions are found and when iter < closeness.
iter = 0; %Initialize iter, which increases with each successful set of target solutions found.
closestTarget = []; %Initialize closestTarget.
%Check the area around the marcher for any nearby targets. Loops until set
%of possible targets are found according to the given degree of closeness.
while isempty( closestTarget )
    steps2Take = steps2Take + 1; %Increment steps2Take.
    %Use the equation of a circle (x-a)^2+(y-b)^2=r^2 where (x,y) are
    %the coordinates from targetPosArr, (a,b) are the coordinates of
    %the initial position of the marcher, and r is steps2Take.
    isClosest = ( targetPosArr( :, 1 ) - initPosArr( marcherTag, 1 ) ) .^ 2 +... 
        ( targetPosArr( :, 2 ) - initPosArr( marcherTag, 2 ) ) .^ 2 <=...
        ( steps2Take .^ 2 ) &...
        ( targetPosArr( :, 1 ) - initPosArr( marcherTag,  1 ) ) .^ 2 +... 
        ( targetPosArr( :, 2 ) - initPosArr( marcherTag, 2 ) ) .^ 2 >=...
        ( ( steps2Take - 1 ) .^ 2 );
    if( any( isClosest ) ), iter = iter + 1; end %Increment iter if possible targets are found.
    if( iter == closeness ) %Return the found targets as closestTarget if the degree of closeness is reached.
        closestTarget = targetPosArr( isClosest', : ); 
    end
end
steps = steps2Take; %Once loop is finished, return steps2Take as steps.

end


function [ sortedMarchers ] = prioritySortMarchers( initPosArr, closestTargetArr, stepsArr )
%Sorts marchers according to priorities: 
%1. number of steps and 
%2. number of possible targets.

%Column 1 is composed of the marcher tags.
col1 = ( 1:size( initPosArr, 1 ) )'; 

%Column 2 is composed of the number of steps each marcher takes.
col2 = stepsArr; 

%Column 3 is composed of the number of closest targets for each marcher.
col3 = zeros( size( initPosArr, 1 ), 1 ); 
for tempIndex = 1:length( closestTargetArr ) 
    col3( tempIndex ) = size( closestTargetArr{ tempIndex }, 1 );
end

%First sort the array according to number of steps.
firstSortedArr = sortrows( [ col1 col2 col3], 2 );

%Next, sort the array according to the number of possible targets.
for tempIndex = 0:max( col2 ) %Iterate through array to sort each section.
    range = find( firstSortedArr( :, 2 ) == tempIndex ); %Find rows that will be sorted.
    if( isempty( range ) ), continue; end %If no marcher takes the number of steps equal to tempIndex, skip that number.
    tempSortedArr = sortrows( firstSortedArr( range, : ), 3 );
    sortedMarchers( range( 1 ):range( end ), : ) = tempSortedArr; %Put sorted section back into output array.
end

end

function [ finalTargetPosArr ] = occupyField( target_formation, closestTargetArr, sortedMarchers, initPosArr, targetPosArr )
%Assigns target positions to each marcher. Marchers with higher priority
%according to the sortedMarchers array will be assigned targets first.

%Set up output array.
finalTargetPosArr = zeros( size( sortedMarchers, 1 ), 2 );
%Set up field, an array of 0s. Taken spots of the field will be marked with
%1.
fieldArr = zeros( size( target_formation ) );
%Set up closeness array which has the closeness number for each marcher.
%This will allow us to give different marchers different closeness numbers
%in order to solve duplication problems.
closenessArr = ones( size( sortedMarchers, 1 ), 1 );

%Assign marchers according to priority. The lower the priority number, the 
%earlier the marcher gets assigned.
for priority = 1:size( sortedMarchers, 1 ) %Iterate through sortedMarchers array to check each marcher.
    marcherTag = sortedMarchers( priority, 1 );
    isSolved = false; %Initialize isSolved boolean.
    while ~isSolved %Loop will execute until there is a one-to-one relation between marchers and targets.
        for tempIndex = 1:size( closestTargetArr{ marcherTag }, 1 ) %Check each possible solution of the marcher.
            tempTarget = [ closestTargetArr{ marcherTag }( tempIndex, 1 ), closestTargetArr{ marcherTag }( tempIndex, 2 ) ];
            if( fieldArr( tempTarget( 1 ), tempTarget( 2 ) ) == 0 ) 
                fieldArr( tempTarget( 1 ), tempTarget( 2 ) ) = 1; %If space is empty, occupy it.
                finalTargetPosArr( marcherTag, : ) = tempTarget; %Assign that space to the marcher in finalTargetPosArr.
                isSolved = true; 
                break; %Break out of for loop since solutions have been found. Go to next marcher.
            elseif( tempIndex == size( closestTargetArr{ marcherTag }, 1 ) ) 
                %If marcher has no more solutions, find solutions of next degree of closeness.
                closenessArr( marcherTag ) = closenessArr( marcherTag ) + 1; 
                closestTargetArr{ marcherTag } = findClosestTargettoMarcher( marcherTag, initPosArr, targetPosArr, closenessArr( marcherTag ) );
                isSolved = false;
            end
        end
    end
end

end

function [ waitArr, directionArr ] = assignMovement( initPosArr, targetPosArr, max_beats )
%Checks for collisions and assigns movement directions and wait time to each marcher.

%Initialize waitArr.
waitArr = zeros( size( targetPosArr, 1 ), 1 );
%Initialize directionArr.
directionArr = cell( size( targetPosArr, 1 ), 1 );
%dPos is the basis for the set of movements a marcher can make according to
%the rules of the assignment. A linear combination of these two vectors
%added to the initial position of a marcher will move it to its target
%position on a specific path, which depends on the coefficients in the
%linear combination.
dPos = { [ 0, 1 ], [ 1, 0 ] };
%Set up dx, dy, xdir, and ydir arrays. These are what we will use to make
%linear combinations of dPos.
dx = zeros( size( targetPosArr, 1 ), 1 ); %Displacement on x axis.
dy = zeros( size( targetPosArr, 1 ), 1 ); %Displacement on y axis.
xdir = zeros( size( targetPosArr, 1 ), 1 ); %Direction taken on x axis.
ydir = zeros( size( targetPosArr, 1 ), 1 ); %Direction take on y axis.
%Get dx and dy for each marcher.
for marcherTag = 1:size( targetPosArr, 1 ) 
    dx( marcherTag ) = targetPosArr( marcherTag, 2 ) - initPosArr( marcherTag, 2 );
    dy( marcherTag ) = targetPosArr( marcherTag, 1 ) - initPosArr( marcherTag, 1 ); 
    xdir( marcherTag ) = sign( dx( marcherTag ) );
    ydir( marcherTag ) = sign( dy( marcherTag ) );
end

%Put dx, dy and xdir, ydir in arrays so that later on marchers' paths can
%be switched.
delta = [ dx, dy ];
dir = [ xdir, ydir ];

%Check collisions frame by frame.
nextPosArr = zeros( size( targetPosArr ) ); %Initialize targetPosArr.
firstPath = ones( size( targetPosArr, 1 ), 1 ); %Initialize firstPath, so that marchers that move diagonally will move on x axis first.
secondPath = 2 * ones( size( targetPosArr, 1 ), 1 ); %Initialize secondPath.
frame = 1; %Initialize frame (start at frame 1).
iter = 0; %TEMPORARY FIX to prevent infinite loops
while frame <= max_beats / 2 && iter < 100 %Go through all frames.
    for marcherTag = 1:size( targetPosArr, 1 ) %Iterate through all marchers.
        if( frame - waitArr( marcherTag ) > 0 ) 
            if( frame - waitArr( marcherTag ) <= abs( delta( marcherTag, firstPath( marcherTag ) ) ) ) 
                %Move along firstPath.
                nextPosArr( marcherTag, : ) = initPosArr( marcherTag, : ) + dir( marcherTag, firstPath( marcherTag ) ) * frame * dPos{ firstPath( marcherTag ) };
            else 
                %Move along secondPath
                if( frame - waitArr( marcherTag ) - abs( delta( marcherTag, firstPath( marcherTag ) ) ) <= delta( marcherTag, secondPath( marcherTag ) ) )
                    nextPosArr( marcherTag, : ) = initPosArr( marcherTag, : ) + delta( marcherTag, firstPath( marcherTag ) ) * dPos{ firstPath( marcherTag ) } + dir( marcherTag, secondPath( marcherTag ) ) * ( frame - abs( delta( marcherTag, firstPath( marcherTag ) ) ) ) * dPos{ secondPath( marcherTag ) };
                else
                    nextPosArr( marcherTag, : ) = initPosArr( marcherTag, : ) + delta( marcherTag, firstPath( marcherTag ) ) * dPos{ firstPath( marcherTag ) } + delta( marcherTag, secondPath( marcherTag ) ) * dPos{ secondPath( marcherTag ) };
                end
            end
        end
    end
    
    %Check for collisions.
    for m = 1:size( nextPosArr, 1 )
        for n = 1:size( nextPosArr, 1 )
            if( m ~= n && isequal( nextPosArr( m, : ), nextPosArr( n, : ) ) )
                %If two different rows are equal, there is a collision.
                %First solution is to switch paths.
                if( firstPath( m ) == 1 && firstPath( n ) == 1 )
                    firstPath( m ) = 2; 
                    secondPath( m ) = 1;
                elseif( firstPath( m ) == 2 && firstPath( n ) == 1 )
                    firstPath( n ) = 2;
                    secondPath( n ) = 1;
                elseif( firstPath( m ) == 2 && firstPath( n ) == 2 )
                    firstPath( m ) = 1;
                    secondPath( m ) = 2;
                else
                    %If switching paths doesn't work, make the marcher
                    %wait.
                    if( waitArr( m ) + 1 <= max_beats / 2 - ( abs( dx( m ) ) + abs( dy( m ) ) ) )
                        %Increment wait time until limit. Marcher must
                        %still have time to move to target.
                        waitArr( m ) = waitArr( m ) + 1; 
                    end
                end

                frame = 0;
                break;
            end
        end
        if frame == 0, break; end
    end
    frame = frame + 1; %Go to next frame.
    iter = iter + 1;
end


%Fill direction array. Assign directions based on rules.
for marcherTag = 1:size( targetPosArr, 1 ) 
    switch firstPath( marcherTag )
        case 1
            switch xdir( marcherTag )
                case 1
                    switch ydir( marcherTag )
                        case 1
                            directionArr{ marcherTag } = 'NE';
                        case -1
                            directionArr{ marcherTag } = 'NW';
                        case 0
                            directionArr{ marcherTag } = 'N';
                    end
                case 0
                    switch ydir( marcherTag )
                        case 1
                            directionArr{ marcherTag } = 'E';
                        case -1
                            directionArr{ marcherTag } = 'W';
                        case 0
                            directionArr{ marcherTag } = '.';
                    end
                case -1
                    switch ydir( marcherTag )
                        case 1
                            directionArr{ marcherTag } = 'SE';
                        case -1
                            directionArr{ marcherTag } = 'SW';
                        case 0
                            directionArr{ marcherTag } = 'S';
                    end
            end            
        case 2
            switch ydir( marcherTag )
                case 1
                    switch xdir( marcherTag )
                        case 1
                            directionArr{ marcherTag } = 'EN';
                        case -1
                            directionArr{ marcherTag } = 'ES';
                        case 0
                            directionArr{ marcherTag } = 'E';
                    end
                case 0
                    switch xdir( marcherTag )
                        case 1
                            directionArr{ marcherTag } = 'N';
                        case -1
                            directionArr{ marcherTag } = 'S';
                        case 0
                            directionArr{ marcherTag } = '.';
                    end
                case -1
                    switch xdir( marcherTag )
                        case 1
                            directionArr{ marcherTag } = 'WN';
                        case -1
                            directionArr{ marcherTag } = 'WS';
                        case 0
                            directionArr{ marcherTag } = 'W';
                    end
            end 
    end
        
end

end

